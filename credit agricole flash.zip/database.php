<?php
session_start();
$servername = 'localhost';
$username = 'compteflash';
$password = 'compteflash';
$dbname = 'compteflash';